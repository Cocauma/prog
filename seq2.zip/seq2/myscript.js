$(function() {
	var imgs = "";
	for(var i = 0; i <= 200; i++) {
	imgs += "<img src='img/pic" + i + ".jpg'>";
	}

	$("section").html(imgs);


	$("body").on("mousemove", function(e) {
		var wid = $(window).width();
		var posX = e.pageX;

		var percent = Math.floor((posX / wid) * 200);

		$("section > img").hide();
		$("section > img").eq(percent).show();	
	});

	$("nav > ul > li:nth-child(1)").hover(function(){
		$("nav > ul > li:nth-child(1) > div").css({
			"background":"#d0d0d0"
		});
		$("nav > ul > li > div").css({
			"top":"68px",
			"opacity":"1"
		});
	}, function(){
		$("nav > ul > li > div").css({
			"top":"-50px",
			"opacity":"0"
		});
		$("nav > ul > li:nth-child(1) > div").css({
			"background":""
		});
	});
	$("nav > ul > li:nth-child(2)").hover(function(){
		$("nav > ul > li:nth-child(2) > div").css({
			"background":"#d0d0d0"
		});
		$("nav > ul > li > div").css({
			"top":"68px",
			"opacity":"1"
		});
	}, function(){
		$("nav > ul > li > div").css({
			"top":"-50px",
			"opacity":"0"
		});
		$("nav > ul > li:nth-child(2) > div").css({
			"background":""
		});
	});
	$("nav > ul > li:nth-child(3)").hover(function(){
		$("nav > ul > li:nth-child(3) > div").css({
			"background":"#d0d0d0"
		});
		$("nav > ul > li > div").css({
			"top":"68px",
			"opacity":"1"
		});
	}, function(){
		$("nav > ul > li > div").css({
			"top":"-50px",
			"opacity":"0"
		});
		$("nav > ul > li:nth-child(3) > div").css({
			"background":""
		});
	});
	$("nav > ul > li:nth-child(4)").hover(function(){
		$("nav > ul > li:nth-child(4) > div").css({
			"background":"#d0d0d0"
		});
		$("nav > ul > li > div").css({
			"top":"68px",
			"opacity":"1"
		});
	}, function(){
		$("nav > ul > li > div").css({
			"top":"-50px",
			"opacity":"0"
		});
		$("nav > ul > li:nth-child(4) > div").css({
			"background":""
		});
	});
	$("nav > ul > li:nth-child(5)").hover(function(){
		$("nav > ul > li:nth-child(5) > div").css({
			"background":"#d0d0d0"
		});
		$("nav > ul > li > div").css({
			"top":"68px",
			"opacity":"1"
		});
	}, function(){
		$("nav > ul > li > div").css({
			"top":"-50px",
			"opacity":"0"
		});
		$("nav > ul > li:nth-child(5) > div").css({
			"background":""
		});
	});
	$("nav > ul > li:nth-child(6)").hover(function(){
		$("nav > ul > li:nth-child(6) > div").css({
			"background":"#d0d0d0"
		});
		$("nav > ul > li > div").css({
			"top":"68px",
			"opacity":"1"
		});
	}, function(){
		$("nav > ul > li > div").css({
			"top":"-50px",
			"opacity":"0"
		});
		$("nav > ul > li:nth-child(6) > div").css({
			"background":""
		});
	});
});