$(function(){
	var imgs = "";

	for(var i = 0; i <= 200; i++){
		imgs += "<img src='imgs/pic"+i+".jpg'>";
	}
	$("section").html(imgs);

	$("body").on("mousemove",function(e){
		var wid=$(window).width();
		var x=e.pageX;

		var percent=Math.floor((x/wid)*200);

		$("section > img").hide();
		$("section > img").eq(percent).show();
	});
});