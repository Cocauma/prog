$(function(){
	var clc = false;

	$("nav li").on("click", function(e){

		e.stopPropagation();
		var id = $(this).data("id");

		$("#wrap").removeClass();
		$("#wrap").addClass(id);

		clc = true;

	});

	var timer = setInterval(function(){

		var now = new Date();
		var h = now.getHours();
		var m = now.getMinutes();
		var s = now.getSeconds();

		if(h >= 5 && h < 11) {
			// 5 시에서 11시 사이일 떄
			$("#wrap").removeClass();
			$("#wrap").addClass("morning");
			$("nav li").removeClass();
			$("nav li").eq(0).addClass("on");
		}else if(h >= 11 && h < 16) {
			// 11 시에서 16 시 사이일 떄
			$("#wrap").removeClass();
			$("#wrap").addClass("afternoon");
			$("nav li").removeClass();
			$("nav li").eq(1).addClass("on");
		}else if(h >= 16 && h < 20) {
			// 16 시에서 20 시 사이일 떄
			$("#wrap").removeClass();
			$("#wrap").addClass("evening");
			$("nav li").removeClass();
			$("nav li").eq(2).addClass("on");
		}else if(h >= 20 || h < 5) {
			// 20 시에서 5 시 사이일 떄
			$("#wrap").removeClass();
			$("#wrap").addClass("night");
			$("nav li").removeClass();
			$("nav li").eq(3).addClass("on");
		}

		if(h < 10) { h = "0" + h; }
		if(m < 10) { m = "0" + m; }
		if(s < 10) { s = "0" + s; }

		$("figure p span").eq(0).text(h);
		$("figure p span").eq(1).text(m);
		$("figure p span").eq(2).text(s);
		
	}, 1);

});