$(function(){

	$("#btnDiv").on("click",".abtn",function(e){
		alert("버트니가 눌렸읍니다 ^^7");
	});

	$("#btnAni").on("click", function(e){
		var newBtn = $("<button class='abtn'>얼럿</button>");
		$("#btnDiv").append(newBtn);
	});

	// var toggle = false;

	// $("#btnAni").on("click", function(e){
	// 	$('#a').stop(true, true);
	// 	if(!toggle) {
	// 		$("#a").animate({"left":"500px"},2000);
	// 	}else {
	// 		$("#a").animate({"left":"0px"},2000);
	// 	}
	// 	toggle = !toggle;
	// });
});